Look at keyboard-layout.png and read the following to better understand how to layout/program your pcb.

The colors in the image have important meanings. If you want to use a large left shift for example, then the programming is the same as the small shift(matching colors),
and you ignore the red "|\" key. Red means ignore if you are using a matching color(alternate) layout.

For the top function row, just match the bottom legends to which key you need and the layout, ignoring the red key for programming a keyboard with no top row escape key.

For ISO program the "|\" key next to left shift as if it were one row lower (Column 5, Row 5; Counting starts at Column 0, Row 0).

The Beige function keys can be removed from the pcb by using a small razor saw and cutting on the line marked with the plated holes, or you can use a razor and score down the
same line on both sides and break it off. Be careful when using the second method because if the score lines are not deep enough you may destroy the PCB. To mitigate the risk,
score each side multiple times with quite a bit of force and make sure the score line is fairly deep. Then place the PCB on the edge of a table with the score line lined up
with the edge or just barely off the table, hold both parts firmly and apply force sharply to snap the board cleanly.